package edu.iastate.cs2280.hw3;

import java.util.AbstractSequentialList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 * @author Jared Krug
 */

/**
 * Implementation of the list interface based on linked nodes
 * that store multiple items per node.  Rules for adding and removing
 * elements ensure that each node (except possibly the last one)
 * is at least half full.
 */
public class StoutList<E extends Comparable<? super E>> extends AbstractSequentialList<E>
{
  /**
   * Default number of elements that may be stored in each node.
   */
  private static final int DEFAULT_NODESIZE = 4;
  
  /**
   * Number of elements that can be stored in each node.
   */
  private final int nodeSize;
  
  /**
   * Dummy node for head.  It should be private but set to public here only  
   * for grading purpose.  In practice, you should always make the head of a 
   * linked list a private instance variable.  
   */
  public Node head;
  
  /**
   * Dummy node for tail.
   */
  private Node tail;
  
  /**
   * Number of elements in the list.
   */
  private int size;
  
  /**
   * Constructs an empty list with the default node size.
   */
  public StoutList()
  {
    this(DEFAULT_NODESIZE);
  }

  /**
   * Constructs an empty list with the given node size.
   * @param nodeSize number of elements that may be stored in each node, must be 
   *   an even number
   */
  public StoutList(int nodeSize)
  {
    if (nodeSize <= 0 || nodeSize % 2 != 0) throw new IllegalArgumentException();
    
    // dummy nodes
    head = new Node();
    tail = new Node();
    head.next = tail;
    tail.previous = head;
    this.nodeSize = nodeSize;
  }
  
  /**
   * Constructor for grading only.  Fully implemented. 
   * @param head
   * @param tail
   * @param nodeSize
   * @param size
   */
  public StoutList(Node head, Node tail, int nodeSize, int size)
  {
	  this.head = head; 
	  this.tail = tail; 
	  this.nodeSize = nodeSize; 
	  this.size = size; 
  }

  @Override
  public int size()
  {
    // TODO - DONE
    return size;
  }
  
  @Override
  public boolean add(E item)
  {
    // TODO - DONE
	//Exceptions:
	if (item == null) {
		throw new NullPointerException();
	}
	
	add(size, item);
    return true;
  }

  @Override
  public void add(int pos, E item)
  {
    // TODO - DONE
	if (pos < 0 || pos > size) {
		throw new IndexOutOfBoundsException();
	}
	if (item == null) {
		throw new NullPointerException();
	}
	
	NodeInfo nodeInfo = getNodeInfo(pos);
	add(nodeInfo.node, nodeInfo.offset, item);
	
	// NOTES:
	// I realize I could've made most of this a helper method for later methods but
	// I finished the other methods before this and didn't want to change them.
	// Nevermind, the helper is a lot better. Commented out old code instead of deleting.
	
//	NodeInfo nodeInfo;
//	
//	if (pos == -1) {
//		nodeInfo = new NodeInfo(head, 0);
//		add(nodeInfo.node, nodeInfo.offset, item);
//	}
//	else if (pos == size) {
//		nodeInfo = new NodeInfo(tail, 0);
//		add(nodeInfo.node, nodeInfo.offset, item);
//	}
//	else {
//		Node current = head.next;
//		int index = current.count - 1;
//		
//		while (current != tail && pos > index) {
//			current = current.next;
//			index += current.count;
//		}
//		int offset = current.count + pos - index - 1;
//		
//		nodeInfo = new NodeInfo(current, offset);
//		add(nodeInfo.node, offset, item);
//	}
  }

  @Override
  public E remove(int pos)
  {
    // TODO - DONE
	// NOTE:
	// Didn't use the helper method getNodeInfo() because I had already implemented it and didn't want to change anything.
	
	if (pos < 0 || pos >= size) {
		throw new IndexOutOfBoundsException();
	}
	
	Node current = head.next;
	int index = 0;
	while (current != tail && pos >= index + current.count) {
		index += current.count;
		current = current.next;
	}
	
	int offset = pos - index;
	E removed = current.data[offset]; //item to be removed
	current.removeItem(offset); //remove item
	
	if (current.count < nodeSize / 2) {
		Node successor = current.next;
		if (successor != tail) { //mini-merge
			if (successor.count > nodeSize / 2) {
				current.addItem(current.count, successor.data[0]);
				successor.removeItem(0);
			} else { //full-merge
				for (int i = 0; i < successor.count; i++) {
					current.addItem(current.count, successor.data[i]);
				}
				//disconnect the successor
				successor.previous.next = successor.next;
				successor.next.previous = successor.previous;
			}
		}
	}
	
	//checks if current is last node and only has one element. deletes if true
	if (current.count == 0 && current.next == tail && current.previous != head) {
		current.previous.next = current.next;
		current.next.previous = current.previous;
	}
	
	size--;
    return removed;
  }

  /**
   * Sort all elements in the stout list in the NON-DECREASING order. You may do the following. 
   * Traverse the list and copy its elements into an array, deleting every visited node along 
   * the way.  Then, sort the array by calling the insertionSort() method.  (Note that sorting 
   * efficiency is not a concern for this project.)  Finally, copy all elements from the array 
   * back to the stout list, creating new nodes for storage. After sorting, all nodes but 
   * (possibly) the last one must be full of elements.  
   *  
   * Comparator<E> must have been implemented for calling insertionSort().    
   */
  public void sort()
  {
	  // TODO - DONE
	  
	  //copy elements into an array
	  E[] elements = (E[]) new Comparable[size];
	  Iterator<E> newIterator = iterator();
	  
	  for (int i = 0; i < size; i++) {
		  elements[i] = newIterator.next();  
	  }
	  
	  //destroy
	  head.next = tail;
	  tail.previous = head;
	  size = 0;
	  
	  //sort
	  insertionSort(elements, new ObjectComparator<>());	  
  }
  
  /**
   * Sort all elements in the stout list in the NON-INCREASING order. Call the bubbleSort()
   * method.  After sorting, all but (possibly) the last nodes must be filled with elements.  
   *  
   * Comparable<? super E> must be implemented for calling bubbleSort(). 
   */
  public void sortReverse() 
  {
	  // TODO - DONE
	  E[] elements = (E[]) new Comparable[size];
	  Iterator<E> iterator = iterator();
	  
	  for (int i = 0; i < size; i++) {
		  elements[i] = iterator.next();  
	  }
	  
	  //destroy
	  head.next = tail;
	  tail.previous = head;
	  size = 0;
	  
	  bubbleSort(elements);
	  this.addAll(Arrays.asList(elements));
  }
  
  @Override
  public Iterator<E> iterator()
  {
    // TODO Auto-generated method stub - DONE
    return listIterator();
  }

  @Override
  public ListIterator<E> listIterator()
  {
    // TODO Auto-generated method stub - DONE
    return listIterator(0);
  }

  @Override
  public ListIterator<E> listIterator(int index)
  {
    // TODO Auto-generated method stub - DONE
	if (index < 0 || index > size) {
		throw new IndexOutOfBoundsException();
	}
    return new StoutListIterator(index);
  }
  
  /**
   * Returns a string representation of this list showing
   * the internal structure of the nodes.
   */
  public String toStringInternal()
  {
    return toStringInternal(null);
  }

  /**
   * Returns a string representation of this list showing the internal
   * structure of the nodes and the position of the iterator.
   *
   * @param iter
   *            an iterator for this list
   */
  public String toStringInternal(ListIterator<E> iter) 
  {
      int count = 0;
      int position = -1;
      if (iter != null) {
          position = iter.nextIndex();
      }

      StringBuilder sb = new StringBuilder();
      sb.append('[');
      Node current = head.next;
      while (current != tail) {
          sb.append('(');
          E data = current.data[0];
          if (data == null) {
              sb.append("-");
          } else {
              if (position == count) {
                  sb.append("| ");
                  position = -1;
              }
              sb.append(data.toString());
              ++count;
          }

          for (int i = 1; i < nodeSize; ++i) {
             sb.append(", ");
              data = current.data[i];
              if (data == null) {
                  sb.append("-");
              } else {
                  if (position == count) {
                      sb.append("| ");
                      position = -1;
                  }
                  sb.append(data.toString());
                  ++count;

                  // iterator at end
                  if (position == size && count == size) {
                      sb.append(" |");
                      position = -1;
                  }
             }
          }
          sb.append(')');
          current = current.next;
          if (current != tail)
              sb.append(", ");
      }
      sb.append("]");
      return sb.toString();
  }


  /**
   * Node type for this list.  Each node holds a maximum
   * of nodeSize elements in an array.  Empty slots
   * are null.
   */
  private class Node
  {
    /**
     * Array of actual data elements.
     */
    // Unchecked warning unavoidable.
    public E[] data = (E[]) new Comparable[nodeSize];
    
    /**
     * Link to next node.
     */
    public Node next;
    
    /**
     * Link to previous node;
     */
    public Node previous;
    
    /**
     * Index of the next available offset in this node, also 
     * equal to the number of elements in this node.
     */
    public int count;

    /**
     * Adds an item to this node at the first available offset.
     * Precondition: count < nodeSize
     * @param item element to be added
     */
    void addItem(E item)
    {
      if (count >= nodeSize)
      {
        return;
      }
      data[count++] = item;
      //useful for debugging
//      System.out.println("Added " + item.toString() + " at index " + count + " to node "  + Arrays.toString(data));
    }
  
    /**
     * Adds an item to this node at the indicated offset, shifting
     * elements to the right as necessary.
     * 
     * Precondition: count < nodeSize
     * @param offset array index at which to put the new element
     * @param item element to be added
     */
    void addItem(int offset, E item)
    {
      if (count >= nodeSize)
      {
    	  return;
      }
      for (int i = count - 1; i >= offset; --i)
      {
        data[i + 1] = data[i];
      }
      ++count;

      data[offset] = item;
      //useful for debugging 
//      System.out.println("Added " + item.toString() + " at index " + offset + " to node: "  + Arrays.toString(data));
    }

    /**
     * Deletes an element from this node at the indicated offset, 
     * shifting elements left as necessary.
     * Precondition: 0 <= offset < count
     * @param offset
     */
    void removeItem(int offset)
    {
      E item = data[offset];
      for (int i = offset + 1; i < nodeSize; ++i)
      {
        data[i - 1] = data[i];
      }
      data[count - 1] = null;
      --count;
    }    
  }
 
  private class StoutListIterator implements ListIterator<E>
  {
	// constants you possibly use ...   
	  
	// instance variables ... 
	  
	/**
	 * Represents the current index
	 */
	private int nodeIndex;
	
	/**
	 * Represents if node is removable or not
	 */
	private boolean isRemovable;

	/**
	 * Represents the current node
	 */
	private Node currentNode;
	
	/**
	 * Represents the offset within the node
	 */
	private int currentOffset;
	
	/**
	 * Represents last accessed node
	 */
	private Node lastAccessedNode;
	
	/**
	 * Represents last accessed offset
	 */
	private int lastAccessedOffset;
	
	  
    /**
     * Default constructor 
     */
    public StoutListIterator()
    {
    	// TODO - DONE
    	this(0);
    }

    /**
     * Constructor finds node at a given position.
     * @param pos
     */
    public StoutListIterator(int pos)
    {
    	// TODO - DONE
    	if (pos < 0 || pos > size) {
    		throw new IndexOutOfBoundsException();
    	}
    	
    	//setting up instance variables
    	nodeIndex = pos;
    	isRemovable = false;
    	lastAccessedNode = null;
    	lastAccessedOffset = 0;
    	
    	//setting up currentNode and currentOffset
    	int tempPos = 0;
    	currentNode = head;
    	currentOffset = 0;
    	
    	
    	// LOOK INTO THIS (MIGHT NEED FIXING)    	
    	while (currentNode != null && tempPos + currentNode.count <= nodeIndex) {
    		tempPos += currentNode.count;
    		currentNode = currentNode.next;
    	}
    	
    	if (currentNode != null) {
    		currentOffset = nodeIndex - tempPos;
    	}
    	
    	
    }

    @Override
    public boolean hasNext()
    {
    	// TODO - DONE
    	return nodeIndex < size; //checks for next element
    }

    @Override
    public E next()
    {
    	// TODO - DONE
    	if (!hasNext()) {
    		throw new NoSuchElementException();
    	}
    	
    	//NOTE: Doesn't work properly. Kept in program anyway.
//    	E item = currentNode.data[currentOffset];
//    	lastAccessedNode = currentNode;
//    	lastAccessedOffset = currentOffset;
//    	isRemovable = true;
//    	
//    	if (++currentOffset >= currentNode.count) {
//    		currentNode = currentNode.next;
//    		currentOffset = 0;
//    	}
//    	
//    	nodeIndex++;
//    	System.out.println(nodeIndex);
//    	return item;
    	
    	
    	NodeInfo nodeInfo = getNodeInfo(nodeIndex++);
    	currentNode = nodeInfo.node;
    	currentOffset = nodeInfo.offset;
    	lastAccessedNode = currentNode;
    	lastAccessedOffset = currentOffset;
    	isRemovable = true;
    	return currentNode.data[currentOffset];

    	
    }

    @Override
    public void remove()
    {
    	// TODO - DONE
    	if (!isRemovable) {
    		throw new IllegalStateException();
    	}
    	
    	NodeInfo n = getNodeInfo(nodeIndex);
    	
    	if (lastAccessedNode != n.node || lastAccessedOffset < n.offset) {
    		nodeIndex--;
    	}
    	
    	StoutList.this.remove(nodeIndex);
    	isRemovable = false;
    }
    
    // Other methods you may want to add or override that could possibly facilitate 
    // other operations, for instance, addition, access to the previous element, etc.
    // 
    // ...
    // 
    
    
    /**
     * Method to return next index
     */
    @Override
    public int nextIndex() {
    	return nodeIndex;
    }
    
    /**
     * Method that checks if there is a previous element
     */
    @Override
    public boolean hasPrevious() {
    	return nodeIndex > 0;
    }
    
    /**
     * Method to return previous index
     */
    @Override
    public int previousIndex() {
    	return nodeIndex - 1;
    }
    
    /**
     * Method to get previous element
     */
    @Override
    public E previous() {
    	if (!hasPrevious()) {
    		throw new NoSuchElementException();
    	}
    	
    	//NOTE: Doesn't work properly. Kept in program anyway.
//    	System.out.println(currentOffset);
//    	
//    	if (currentOffset == 0) {
//    		currentNode = currentNode.previous;
//    		currentOffset = currentNode.count - 1;
//    	}
//    	
//    	System.out.println(currentOffset);
//    	
//    	E item = currentNode.data[currentOffset];
//    	lastAccessedNode = currentNode;
//    	lastAccessedOffset = currentOffset;
//    	isRemovable = true;
//    	nodeIndex--;
//    	return item;
    	
    	NodeInfo nodeInfo = getNodeInfo(--nodeIndex);
    	currentNode = nodeInfo.node;
   		currentOffset = nodeInfo.offset;
    		
    	lastAccessedNode = currentNode;
   		lastAccessedOffset = currentOffset;
    	
    	isRemovable = true;
    	return currentNode.data[currentOffset];
    	
    	// For debugging purposes:
//        // Debug print: Before moving to previous
//        System.out.println("Before previous(): nodeIndex=" + nodeIndex + ", currentNode=" + currentNode + ", currentOffset=" + currentOffset);
//
//        // Decrement the index and get updated node/offset
//        NodeInfo nodeInfo = getNodeInfo(--nodeIndex);
//        currentNode = nodeInfo.node;
//        currentOffset = nodeInfo.offset;
//
//        // Update last accessed fields for remove()
//        lastAccessedNode = currentNode;
//        lastAccessedOffset = currentOffset;
//
//        isRemovable = true; // Allow removal of this element
//
//        // Debug print: After moving to previous
//        System.out.println("After previous(): nodeIndex=" + nodeIndex + ", currentNode=" + currentNode + ", currentOffset=" + currentOffset);
//        System.out.println("Returned value: " + currentNode.data[currentOffset]);
//
//        return currentNode.data[currentOffset];
    }
    
    /**
     * Method to set element at current index
     */
    @Override
    public void set(E item) {
    	if (!isRemovable) {
    		throw new IllegalStateException();
    	}
    	lastAccessedNode.data[lastAccessedOffset] = item;
    }
    
    /**
     * Method to add element
     */
    @Override
    public void add(E item) {
    	if (item == null) {
    		throw new NullPointerException();
    	}
    	StoutList.this.add(nodeIndex++, item);
    	isRemovable = false;
    } 
    
  }
  

  /**
   * Sort an array arr[] using the insertion sort algorithm in the NON-DECREASING order. 
   * @param arr   array storing elements from the list 
   * @param comp  comparator used in sorting 
   */
  private void insertionSort(E[] arr, Comparator<? super E> comp)
  {
	  // TODO - DONE
	  for (int i = 1; i < arr.length; i++) {
		  E temp = arr[i]; //current element
		  int prev = i - 1; //previous element
		  
		  while (prev > -1 && comp.compare(arr[prev], temp) > 0) {
			  arr[prev+1] = arr[prev];
			  prev--;
		  }
		  
		  arr[prev+1] = temp;
		  
	  }
	  
	  this.addAll(Arrays.asList(arr));
	  
  }
  
  /**
   * Sort arr[] using the bubble sort algorithm in the NON-INCREASING order. For a 
   * description of bubble sort please refer to Section 6.1 in the project description. 
   * You must use the compareTo() method from an implementation of the Comparable 
   * interface by the class E or ? super E. 
   * @param arr  array holding elements from the list
   */
  private void bubbleSort(E[] arr)
  {
	  // TODO - DONE
	  boolean swapped;
	  
	  for (int n = arr.length; n > 1; n--) {
		  swapped = false;
		  
		  for (int i = 1; i < n; i++) {
			  if (arr[i-1].compareTo(arr[i]) < 0) {
				  E temp = arr[i-1];
				  arr[i-1] = arr[i];
				  arr[i] = temp;
				  
				  swapped = true;
			  }
		  }
		  if (!swapped) break;
	  }
  }
  
  
  
  /**
   * HELPER METHOD(CLASS)
   * Class to store node and offset info
   */
  private class NodeInfo {
	  Node node;
	  int offset;
	  
	  NodeInfo(Node node, int offset) {
		  this.node = node;
		  this.offset = offset;
	  }
  }
  
  /**
   * HELPER METHOD
   * Adds an element at given position
   * @param n - the given node
   * @param offset - the given offset 
   * @param item - the item to add
   * @return newN - the new node
   */
  private NodeInfo add(Node n, int offset, E item) {
	  //NOTE: Stopped working so I changed it...
//	  if (item == null) {
//		  throw new NullPointerException();
//	  }
//	  
//	  if (offset == 0 && n.previous != head && n.previous.count < nodeSize) {
//		  n.previous.addItem(n.previous.count, item);
//		  return new NodeInfo(n.previous, n.previous.count - 1);
//	  }
//	  
//	  if (n.count == nodeSize) {
//		  Node newNode = new Node();
//		  int half = nodeSize / 2;
//		  
//		  //move half to newNode
//		  for (int i = half; i < nodeSize; i++) {
//			  newNode.addItem(i-half, n.data[i]);
//			  n.data[i] = null;
//		  }
//		  n.count = half;
//		  
//		  //update the links
//		  newNode.next = n.next;
//		  if (n.next != null) {
//			  n.next.previous = newNode;
//		  }
//		  newNode.previous = n;
//		  n.next = newNode;
//		  
//		  if (n == tail) {
//			  tail.previous = newNode;
//		  }
//		  
//		  //add item
//		  if (offset <= half) {
//			  n.addItem(offset, item);
//			  return new NodeInfo(n, offset);
//		  } else {
//			  newNode.addItem(offset - half, item);
//			  return new NodeInfo(newNode, offset - half);
//		  }
//	  } else {
//		  n.addItem(offset, item);
//		  return new NodeInfo(n, offset);
//	  }
	  
	  
	  //Now works and uses helper - connect()
	  //I apologize if it is hard to read
	  
	  if (item == null) {
		  throw new NullPointerException();
	  }
	  
	  NodeInfo newN;
	  
	  //case: Add at start
	  if (offset == 0) {
		  if (size == 0) {
			  //if empty, create new node
			  Node newData = new Node();
			  newData.addItem(item);
			  connect(head, newData);
			  newN = new NodeInfo(newData, 0);
		  } else if (n.previous.count < nodeSize && n.previous != null) {
			  //add to previous node if there is space
			  n.previous.addItem(item);
			  newN = new NodeInfo(n.previous, n.previous.count - 1);
		  } else if (n == tail && n.previous.count == nodeSize) {
			  //create new node and connect
			  Node newData = new Node();
			  newData.addItem(item);
			  connect(tail.previous, newData);
			  newN = new NodeInfo(newData, 0);
		  } else {
			  //
			  n.addItem(offset, item);
			  newN = new NodeInfo(n, offset);
		  }
	  } else {
		  //case: add within or after
		  if (n.count < nodeSize) {
			  //space in urrent node
			  n.addItem(offset, item);
			  newN = new NodeInfo(n, offset);
		  } else {
			  //split
			  Node newData = new Node();
			  connect(n, newData);
			  
			  for (int i = nodeSize - 1; i >= nodeSize-(nodeSize/2); i--) {
				  newData.addItem(0, n.data[i]);
				  n.removeItem(i);
			  }
			  if (offset <= nodeSize/2) {
				  //add to original node
				  n.addItem(offset, item);
				  newN = new NodeInfo(n, offset);
			  } else {
				  //add to new node
				  newData.addItem(offset - (nodeSize/2), item);
				  newN = new NodeInfo(newData, offset - (nodeSize/2));
			  }
		  }
	  }
	  size++;
	  return newN;	  
  }
  
  /**
   * HELPER METHOD
   * Used to connect nodes together.
   * Happens multiple times so an independent method is justified to prevent duplicate code
   * @param current - current node
   * @param nextN - next node
   */
  private void connect(Node current, Node nextN) {
	  nextN.previous = current;
	  nextN.next = current.next;
	  current.next.previous = nextN;
	  current.next = nextN;
  }
  
  /**
   * HELPER METHOD
   * Used to get the node and it's offset for ease of access and easily readable code
   * @param pos - position of node
   * @return the node and offset information
   */
  private NodeInfo getNodeInfo(int pos) {
	  if (pos == -1) {
		  return new NodeInfo(head, 0);
	  }
	  if (pos == size) {
		  return new NodeInfo(tail, 0);
	  }
	  
	  Node current = head.next;
	  int index = current.count - 1;
	  
	  while (current != tail && pos > index) {
		  current = current.next;
		  index += current.count;
	  }
	  int offset = current.count + pos - index - 1;
	  
	  return new NodeInfo(current, offset);
  }
  
  /**
   * HELPER METHOD
   * Used for insertionSort
   * @param <E>
   */
  private static class ObjectComparator<E extends Comparable<? super E>> implements Comparator<E> {
	  @Override
	  public int compare(E first, E second) {
		  return first.compareTo(second);
	  }
  }
}